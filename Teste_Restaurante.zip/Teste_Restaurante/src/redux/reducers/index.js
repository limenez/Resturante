import { combineReducers } from 'redux';

import restaurants from '../modules/restaurants';

export default combineReducers({
  restaurants,
});
